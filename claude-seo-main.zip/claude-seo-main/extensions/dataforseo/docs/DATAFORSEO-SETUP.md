# DataForSEO Account Setup

Step-by-step guide to getting DataForSEO API credentials for the Claude SEO extension.

## 1. Create Account

1. Go to [app.dataforseo.com/register](https://app.dataforseo.com/register)
2. Sign up with your email address
3. Verify your email

New accounts include a free trial balance for testing.

## 2. Find API Credentials

1. Log in to [app.dataforseo.com](https://app.dataforseo.com)
2. Go to **API Access** in the left sidebar
3. Your credentials are:
   - **Username**: Your registered email address
   - **Password**: Your API password (set during registration)

These are the values you'll enter when running the extension installer.

## 3. Understanding Credits

DataForSEO uses a credit-based system:

- Each API call costs a small number of credits
- Different endpoints have different costs
- Credits are purchased in advance
- Monitor usage at [app.dataforseo.com/dashboard](https://app.dataforseo.com/dashboard)

**Typical costs per call, verified as of 2026-07-10:**

| Endpoint Type | Approximate Cost |
|--------------|-----------------|
| SERP (single query) | $0.001-0.003 |
| Keyword volume (per keyword) | $0.0005-0.002 |
| Backlink summary | $0.002-0.005 |
| Backlink list | $0.005-0.01 |
| On-page crawl (per page) | $0.01-0.05 |
| AI optimization (per call) | $0.05 |

## 4. Manual MCP Configuration

If the installer's auto-configuration fails, add this to `~/.claude.json`:

```json
{
  "mcpServers": {
    "dataforseo": {
      "command": "npx",
      "args": ["-y", "dataforseo-mcp-server"],
      "env": {
        "DATAFORSEO_USERNAME": "<account-username>",
        "DATAFORSEO_PASSWORD": "your-api-password",
        "ENABLED_MODULES": "SERP,KEYWORDS_DATA,ONPAGE,DATAFORSEO_LABS,BACKLINKS,DOMAIN_ANALYTICS,BUSINESS_DATA,CONTENT_ANALYSIS,AI_OPTIMIZATION",
        "FIELD_CONFIG_PATH": "/path/to/dataforseo-field-config.json"
      }
    }
  }
}
```

Replace the username, password, and FIELD_CONFIG_PATH with your actual values.

## 5. Verify Installation

After installing, start Claude Code and run:

```
/seo dataforseo serp test query
```

If you see search results, the extension is working correctly.
