#!/usr/bin/env python3
"""
Moz Link Explorer API client for Claude SEO.

Queries the Moz v2 REST API for Domain Authority, Page Authority,
Spam Score, link counts, and referring domain data. Uses a conservative
10-second default delay; verify current Moz plan limits and rely on live
429 handling.

Usage:
    python moz_api.py metrics https://example.com --json
    python moz_api.py domains https://example.com --json
    python moz_api.py anchors https://example.com --json
    python moz_api.py pages example.com --json
"""

import argparse
import base64
import json
import sys
import time

try:
    import requests
except ImportError:
    print("Error: requests library required. Install with: pip install requests")
    sys.exit(1)

# Import credential helpers (same directory)
import os

_SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _SCRIPTS_DIR)
try:
    from backlinks_auth import get_moz_api_key
    from google_auth import validate_url
except ImportError:
    print("Error: backlinks_auth.py and google_auth.py required in scripts/", file=sys.stderr)
    sys.exit(1)

MOZ_BASE = "https://api.moz.com"
# Legacy JSON-RPC endpoint was deprecated; Moz migrated to v2 REST.
# All four legacy methods map to dedicated v2 REST paths.

# Conservative default delay; verify current Moz plan limits.
RATE_LIMIT_DELAY = 10
RATE_LIMIT_FILE = os.path.expanduser("~/.cache/claude-seo/moz_last_request.lock")


def _moz_basic_auth_header(api_key: str) -> str | None:
    """Return a Basic auth header for accessId:secret credentials."""
    if ":" in api_key:
        encoded = base64.b64encode(api_key.encode("utf-8")).decode("ascii")
        return f"Basic {encoded}"

    try:
        decoded = base64.b64decode(api_key, validate=True).decode("utf-8")
    except (ValueError, UnicodeDecodeError):
        return None
    if ":" not in decoded:
        return None
    return f"Basic {api_key}"


def _rate_limit():
    """Apply the conservative Moz request delay.

    Persists timestamp to a lockfile so the limit is respected across
    separate CLI invocations (each call is a new process).
    """
    os.makedirs(os.path.dirname(RATE_LIMIT_FILE), exist_ok=True)

    try:
        with open(RATE_LIMIT_FILE, "a+") as f:
            try:
                import fcntl
                fcntl.flock(f, fcntl.LOCK_EX)
            except (ImportError, OSError):
                pass  # Windows or lock unavailable: skip locking

            f.seek(0)
            content = f.read().strip()
            last_time = float(content) if content else 0

            now = time.time()
            elapsed = now - last_time
            if elapsed < RATE_LIMIT_DELAY and last_time > 0:
                time.sleep(RATE_LIMIT_DELAY - elapsed)

            f.seek(0)
            f.truncate()
            f.write(str(time.time()))
    except (IOError, ValueError):
        pass  # If lockfile fails, fall back to no rate limiting (server-side 429 handles it)


def _moz_request(path: str, body: dict, api_key: str) -> dict:
    """
    Make a v2 REST request to the Moz API.

    Args:
        path: API path (e.g., '/v2/url_metrics').
        body: Request body for the endpoint.
        api_key: Moz API key.

    Returns:
        Dictionary with 'status', 'data', 'error', 'metadata'.
    """
    _rate_limit()

    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ClaudeSEO/1.8.0",
    }
    basic_auth = _moz_basic_auth_header(api_key)
    if basic_auth:
        headers["Authorization"] = basic_auth
    else:
        headers["x-moz-token"] = api_key

    try:
        response = requests.post(
            MOZ_BASE + path,
            json=body,
            headers=headers,
            timeout=30,
        )

        if response.status_code == 429:
            return {
                "status": "rate_limited",
                "data": None,
                "error": "Moz rate limit exceeded. Wait and verify current plan limits.",
                "metadata": {"source": "moz", "rate_limited": True},
            }

        if response.status_code == 401:
            return {
                "status": "error",
                "data": None,
                "error": "Invalid Moz API key. Check your key at https://moz.com/products/api/keys",
                "metadata": {"source": "moz"},
            }

        if response.status_code == 403:
            return {
                "status": "error",
                "data": None,
                "error": "Moz API access denied. Free tier may not include this endpoint.",
                "metadata": {"source": "moz"},
            }

        # v2 REST returns 400 with {"error": "..."} on bad requests
        if response.status_code >= 400:
            try:
                err_body = response.json()
                err_msg = err_body.get("error") or err_body.get("message") or response.text
            except ValueError:
                err_msg = response.text or f"HTTP {response.status_code}"
            return {
                "status": "error",
                "data": None,
                "error": f"HTTP {response.status_code}: {err_msg}",
                "metadata": {"source": "moz", "path": path},
            }

        result = response.json()

        return {
            "status": "success",
            "data": result,
            "error": None,
            "metadata": {
                "source": "moz",
                "path": path,
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            },
        }

    except requests.exceptions.Timeout:
        return {
            "status": "error",
            "data": None,
            "error": "Request timed out after 30 seconds",
            "metadata": {"source": "moz"},
        }
    except requests.exceptions.RequestException as e:
        return {
            "status": "error",
            "data": None,
            "error": str(e),
            "metadata": {"source": "moz"},
        }


def get_url_metrics(url: str, api_key: str) -> dict:
    """
    Get URL-level metrics: Domain Authority, Page Authority, Spam Score, link counts.

    Args:
        url: Target URL or domain.
        api_key: Moz API key.

    Returns:
        Standard response dict with metrics data.
    """
    target = url.replace("https://", "").replace("http://", "").rstrip("/")
    body = {"targets": [target]}
    result = _moz_request("/v2/url_metrics", body, api_key)

    if result["status"] == "success" and result["data"]:
        results = result["data"].get("results") or []
        data = results[0] if results else {}
        result["data"] = {
            "url": url,
            "domain_authority": data.get("domain_authority"),
            "page_authority": data.get("page_authority"),
            "spam_score": data.get("spam_score"),
            "links": data.get("external_pages_to_root_domain", 0),
            "external_links": data.get("external_pages_to_root_domain", 0),
            "linking_root_domains": data.get("root_domains_to_root_domain", 0),
            "last_crawled": data.get("last_crawled"),
            "raw": data,
        }

    return result


def get_linking_domains(url: str, api_key: str, limit: int = 50) -> dict:
    """
    Get top referring domains linking to the target.

    Args:
        url: Target URL or domain.
        api_key: Moz API key.
        limit: Max domains to return (default 50).

    Returns:
        Standard response dict with referring domain list.
    """
    target = url.replace("https://", "").replace("http://", "").rstrip("/")
    body = {
        "target": target,
        "target_scope": "root_domain",
        "limit": min(limit, 50),
    }
    result = _moz_request("/v2/linking_root_domains", body, api_key)

    if result["status"] == "success" and result["data"]:
        results_list = result["data"].get("results") or []
        domains = []
        for item in results_list:
            to_target = item.get("to_target", {}) or {}
            domains.append({
                "domain": item.get("root_domain", ""),
                "domain_authority": item.get("domain_authority"),
                "page_authority": None,
                "spam_score": item.get("spam_score"),
                "links_to_target": to_target.get("pages", 1),
            })
        result["data"] = {
            "target": url,
            "total_returned": len(domains),
            "referring_domains": domains,
        }

    return result


def get_anchor_text(url: str, api_key: str, limit: int = 50) -> dict:
    """
    Get anchor text distribution for a target domain.

    Args:
        url: Target URL or domain.
        api_key: Moz API key.
        limit: Max anchor texts to return.

    Returns:
        Standard response dict with anchor text data.
    """
    target = url.replace("https://", "").replace("http://", "").rstrip("/")
    body = {
        "target": target,
        "target_scope": "root_domain",
        "limit": min(limit, 50),
    }
    result = _moz_request("/v2/anchor_text", body, api_key)

    if result["status"] == "success" and result["data"]:
        results_list = result["data"].get("results") or []
        anchors = []
        for item in results_list:
            anchors.append({
                "anchor_text": item.get("anchor_text", ""),
                "external_links": item.get("external_pages", 0),
                "linking_domains": item.get("external_root_domains", 0),
            })
        result["data"] = {
            "target": url,
            "total_returned": len(anchors),
            "anchor_texts": anchors,
        }

    return result


def get_top_pages(domain: str, api_key: str, limit: int = 50) -> dict:
    """
    Get top pages by backlink count for a domain.

    Args:
        domain: Target domain.
        api_key: Moz API key.
        limit: Max pages to return.

    Returns:
        Standard response dict with top pages data.
    """
    target = domain.replace("https://", "").replace("http://", "").rstrip("/")
    body = {
        "target": target,
        "target_scope": "root_domain",
        "limit": min(limit, 50),
    }
    result = _moz_request("/v2/top_pages", body, api_key)

    if result["status"] == "success" and result["data"]:
        results_list = result["data"].get("results") or []
        pages = []
        for item in results_list:
            pages.append({
                "url": item.get("page", ""),
                "page_authority": item.get("page_authority"),
                "links": item.get("external_pages_to_page", 0),
                "linking_domains": item.get("root_domains_to_page", 0),
            })
        result["data"] = {
            "domain": domain,
            "total_returned": len(pages),
            "top_pages": pages,
        }

    return result


def main():
    parser = argparse.ArgumentParser(
        description="Moz Link Explorer API client for Claude SEO"
    )
    parser.add_argument(
        "command",
        choices=["metrics", "domains", "anchors", "pages"],
        help="API command: metrics (DA/PA), domains (referring), anchors (text), pages (top)",
    )
    parser.add_argument(
        "url",
        help="Target URL or domain to analyze",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=50,
        help="Max results to return (default: 50, max: 100)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output as JSON",
    )

    args = parser.parse_args()

    # Validate URL
    target = args.url
    if target.lower().startswith("http"):
        if not validate_url(target):
            result = {
                "status": "error",
                "data": None,
                "error": f"Invalid or blocked URL: {target}",
                "metadata": {"source": "moz"},
            }
            if args.json:
                print(json.dumps(result, indent=2))
            else:
                print(f"Error: {result['error']}", file=sys.stderr)
            sys.exit(1)

    # Get API key
    api_key = get_moz_api_key()
    if not api_key:
        result = {
            "status": "error",
            "data": None,
            "error": "No Moz API key configured. Run: python scripts/backlinks_auth.py --setup",
            "metadata": {"source": "moz"},
        }
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"Error: {result['error']}", file=sys.stderr)
        sys.exit(1)

    # Execute command
    if args.command == "metrics":
        result = get_url_metrics(target, api_key)
    elif args.command == "domains":
        result = get_linking_domains(target, api_key, limit=args.limit)
    elif args.command == "anchors":
        result = get_anchor_text(target, api_key, limit=args.limit)
    elif args.command == "pages":
        result = get_top_pages(target, api_key, limit=args.limit)
    else:
        result = {"status": "error", "data": None, "error": f"Unknown command: {args.command}"}

    # Output
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        if result["status"] == "success" and result["data"]:
            data = result["data"]
            if args.command == "metrics":
                print(f"Moz Metrics for: {data.get('url', target)}")
                print(f"  Domain Authority: {data.get('domain_authority', 'N/A')}")
                print(f"  Page Authority:   {data.get('page_authority', 'N/A')}")
                print(f"  Spam Score:       {data.get('spam_score', 'N/A')}")
                print(f"  Linking Domains:  {data.get('linking_root_domains', 'N/A')}")
                print(f"  External Links:   {data.get('external_links', 'N/A')}")
            elif args.command == "domains":
                print(f"Referring Domains for: {data.get('target', target)} ({data.get('total_returned', 0)} returned)")
                for d in data.get("referring_domains", [])[:20]:
                    print(f"  {d.get('domain', '?'):40s} DA={d.get('domain_authority', '?'):>5} links={d.get('links_to_target', '?')}")
            elif args.command == "anchors":
                print(f"Anchor Text for: {data.get('target', target)} ({data.get('total_returned', 0)} returned)")
                for a in data.get("anchor_texts", [])[:20]:
                    print(f"  {a.get('anchor_text', '?'):50s} links={a.get('external_links', '?')} domains={a.get('linking_domains', '?')}")
            elif args.command == "pages":
                print(f"Top Pages for: {data.get('domain', target)} ({data.get('total_returned', 0)} returned)")
                for p in data.get("top_pages", [])[:20]:
                    print(f"  PA={p.get('page_authority', '?'):>5} links={p.get('links', '?'):>6} {p.get('url', '?')}")
        elif result["error"]:
            print(f"Error: {result['error']}", file=sys.stderr)
        else:
            print("No data returned.", file=sys.stderr)


if __name__ == "__main__":
    main()
